/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Adi
 */
public class Main {
    
    public static void main (String[]args) throws ParserConfigurationException, SAXException, IOException, ParseException{
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setIgnoringElementContentWhitespace(true);
        DocumentBuilder dBuilder = dbf.newDocumentBuilder();
        
        Document doc = dBuilder.parse("index.xml");
        
        Element r = doc.getDocumentElement();
        NodeList books = r.getElementsByTagName("book");
        for(int i=0;i<books.getLength();i++){
                 NodeList price = ((Element)books.item(i)).getElementsByTagName("price");
                 for(int u=0;u<price.getLength();u++){
                     double tagPrice = Double.valueOf(price.item(u).getTextContent());
                     if(tagPrice>10.00){
                         //System.out.println(books.item(i).getTextContent());
                        NodeList date = ((Element)books.item(i)).getElementsByTagName("publish_date");
                        for(int j=0;j<date.getLength();j++){
                            String dDatum = date.item(u).getTextContent();
                            String zadaniDatum = "2005-01-01";
                            SimpleDateFormat dtf = new SimpleDateFormat("yyyy-MM-dd");
                            Date dateParisani = dtf.parse(dDatum);
                            Date dateParsirani2 = dtf.parse(zadaniDatum);
                            
                            if(dateParisani.after(dateParsirani2)){
                                System.out.println("Autor knjige je: "+ books.item(i).getFirstChild().getNextSibling().getTextContent());
                                System.out.println("Naziv knjige je: "+ books.item(i).getFirstChild().getNextSibling().getNextSibling().getNextSibling().getTextContent());
                                System.out.println("Zanr knjige je: "
                                        + books.item(i).getFirstChild().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getNextSibling().getTextContent());
                                System.out.println("Cijena knjige je: "+ 
                                        books.item(i).getLastChild().getPreviousSibling().getPreviousSibling().getPreviousSibling().getPreviousSibling().getPreviousSibling().getTextContent());
                                System.out.println("Datum izdavanja knjige je: "+ 
                                        books.item(i).getLastChild().getPreviousSibling().getPreviousSibling().getPreviousSibling().getTextContent());
                                System.out.println("Opis knjige je: "+ 
                                        books.item(i).getLastChild().getPreviousSibling().getTextContent());
                            }
                        }
                     }
                     
                     }

        
        }
        
       
        
        
    }
    
}
